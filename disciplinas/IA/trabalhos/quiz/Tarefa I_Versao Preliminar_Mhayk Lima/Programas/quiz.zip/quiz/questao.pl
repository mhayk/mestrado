/*
Prolog Script Quiz.
Aluno: Mhayk Whandson da Silva Lima
UFAM - Universidade Federal do Amazonas
Disciplina: Inteligência Artificial.
*/
:- encoding(utf8).


enunciado(1,'Qual é o maior estado do brasil ?', ['Rio de Janeiro','Rio Grande do Sul', 'Amazonas'], 'Amazonas').
enunciado(2,'Qual é a capital de Roraima ?', ['Boa Vista','Rio Branco', 'Manaus'], 'Boa Vista').
enunciado(3,'Qual é a capital do Amazonas ?', ['Boa Vista','Rio Branco', 'Manaus'], 'Manaus').
enunciado(4,'Qual é a capital do Ceará ?', ['Fortaleza','Salvador', 'Manaus'], 'Fortaleza').
enunciado(5,'Qual é a capital do Rio Grande do Sul ?', ['Campo Grande','Porto Alegre', 'Manaus'], 'Porto Alegre').
enunciado(6,'Qual é a capital de Minas Gerais ?', ['Campo Grande','Porto Alegre', 'Belo Horizonte'], 'Belo Horizonte').
enunciado(7,'Qual é a capital de Pernambuco ?', ['Recife','Porto Alegre', 'Belo Horizonte'], 'Recife').
enunciado(8,'Qual é a capital de Sergipe ?', ['Campo Grande','Aracaju', 'Belo Horizonte'], 'Aracaju').
enunciado(9,'Qual é o segundo maior estado do Brasil ?', ['Campo Grande','Pará', 'Belo Horizonte'], 'Pará').

questao(I) :-
        enunciado(I,P,A,R),!,
	write(P),
	nl,
	write(A),
	nl,
	write(R).

resposta(I,X) :-
	enunciado(I,_,_,X),
	write(X).
		

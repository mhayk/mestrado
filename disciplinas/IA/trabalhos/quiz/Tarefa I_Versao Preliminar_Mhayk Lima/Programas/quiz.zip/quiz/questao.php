<?  
include 'decode.php';

$questao = $_POST['questao'];
$resposta = $_POST['alternativa'];

$query = $questao . ',X';

$cmd = "nice -n15 /usr/bin/swipl -f questao.pl -g resposta\(" . $query . "\),halt -q;";

exec( $cmd, $output );

echo unicode_decode($output[0]);

?>
